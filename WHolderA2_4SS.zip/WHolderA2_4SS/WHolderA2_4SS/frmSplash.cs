﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WHolderA2_4SS
{
    public partial class frmSplash : Form
    {
        public frmSplash()
        {
            InitializeComponent();
        }

        private void frmSplash_Load(object sender, EventArgs e)
        {
            tmrLoading.Start();
        }

        private void tmrLoading_Tick(object sender, EventArgs e)
        {
            tmrLoading.Stop();

            frmMain main = new frmMain();

            main.Show();

            this.Hide();
        }
    }
}
