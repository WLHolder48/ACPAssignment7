﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WHolderA2_4SS
{
    public partial class frmMain : Form
    {
        int numA = 0;
        int numB = 0;

        //1 = Addition, 2 = Subtraction, 3 = Multiplication, 4 = Division
        int eMode = 0;

        bool showingResults = false;

        public frmMain()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            eMode = 1;
            lblEMode.Text = "+";

            numA = int.Parse(lblDisplay.Text);
            lblDisplay.Text = "0";

            btnEquals.Enabled = true;

            btnAdd.Enabled = false;
            btnSubtract.Enabled = false;
            btnMultiply.Enabled = false;
            btnDivide.Enabled = false;

            if(showingResults)
            {
                showingResults = false;
            }
        }

        private void btnSubtract_Click(object sender, EventArgs e)
        {
            eMode = 2;
            lblEMode.Text = "-";

            numA = int.Parse(lblDisplay.Text);
            lblDisplay.Text = "0";

            btnEquals.Enabled = true;

            btnAdd.Enabled = false;
            btnSubtract.Enabled = false;
            btnMultiply.Enabled = false;
            btnDivide.Enabled = false;

            if(showingResults)
            {
                showingResults = false;
            }
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            eMode = 3;
            lblEMode.Text = "*";

            numA = int.Parse(lblDisplay.Text);
            lblDisplay.Text = "0";

            btnEquals.Enabled = true;

            btnAdd.Enabled = false;
            btnSubtract.Enabled = false;
            btnMultiply.Enabled = false;
            btnDivide.Enabled = false;

            if(showingResults)
            {
                showingResults = false;
            }
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            eMode = 4;
            lblEMode.Text = "/";

            numA = int.Parse(lblDisplay.Text);
            lblDisplay.Text = "0";

            btnEquals.Enabled = true;

            btnAdd.Enabled = false;
            btnSubtract.Enabled = false;
            btnMultiply.Enabled = false;
            btnDivide.Enabled = false;

            if(showingResults)
            {
                showingResults = false;
            }
        }

        private void btnEquals_Click(object sender, EventArgs e)
        {
            numB = int.Parse(lblDisplay.Text);

            if(eMode == 1)
            {
                lblDisplay.Text = (numA + numB).ToString();
            }
            else if (eMode == 2)
            {
                lblDisplay.Text = (numA - numB).ToString();
            }
            else if (eMode == 3)
            {
                lblDisplay.Text = (numA * numB).ToString();
            }
            else if (eMode == 4)
            {
                if(numB == 0)
                {
                    MessageBox.Show("Cannot divide by zero.");
                }
                else
                {
                    lblDisplay.Text = (numA / numB).ToString();
                }
            }

            showingResults = true;

            btnEquals.Enabled = false;

            btnAdd.Enabled = true;
            btnSubtract.Enabled = true;
            btnMultiply.Enabled = true;
            btnDivide.Enabled = true;

            lblEMode.Text = "";
        }

        private void btnOne_Click(object sender, EventArgs e)
        {
            if(showingResults)
            {
                lblDisplay.Text = "0";
                showingResults = false;
            }

            lblDisplay.Text += "1";
        }

        private void btnTwo_Click(object sender, EventArgs e)
        {
            if (showingResults)
            {
                lblDisplay.Text = "0";
                showingResults = false;
            }

            lblDisplay.Text += "2";
        }

        private void btnThree_Click(object sender, EventArgs e)
        {
            if (showingResults)
            {
                lblDisplay.Text = "0";
                showingResults = false;
            }

            lblDisplay.Text += "3";
        }

        private void btnFour_Click(object sender, EventArgs e)
        {
            if (showingResults)
            {
                lblDisplay.Text = "0";
                showingResults = false;
            }

            lblDisplay.Text += "4";
        }

        private void btnFive_Click(object sender, EventArgs e)
        {
            if (showingResults)
            {
                lblDisplay.Text = "0";
                showingResults = false;
            }

            lblDisplay.Text += "5";
        }

        private void btnSix_Click(object sender, EventArgs e)
        {
            if (showingResults)
            {
                lblDisplay.Text = "0";
                showingResults = false;
            }

            lblDisplay.Text += "6";
        }

        private void btnSeven_Click(object sender, EventArgs e)
        {
            if (showingResults)
            {
                lblDisplay.Text = "0";
                showingResults = false;
            }

            lblDisplay.Text += "7";
        }

        private void btnEight_Click(object sender, EventArgs e)
        {
            if (showingResults)
            {
                lblDisplay.Text = "0";
                showingResults = false;
            }

            lblDisplay.Text += "8";
        }

        private void btnNine_Click(object sender, EventArgs e)
        {
            if (showingResults)
            {
                lblDisplay.Text = "0";
                showingResults = false;
            }

            lblDisplay.Text += "9";
        }

        private void btnZero_Click(object sender, EventArgs e)
        {
            if (showingResults)
            {
                lblDisplay.Text = "0";
                showingResults = false;
            }

            lblDisplay.Text += "0";
        }
    }
}
